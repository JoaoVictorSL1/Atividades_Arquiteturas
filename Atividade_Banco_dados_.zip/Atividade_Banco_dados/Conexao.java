public interface Conexao {
    void conectar();
}
